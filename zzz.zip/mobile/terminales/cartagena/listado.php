<?php
include ("conectar_db.php");
include ("../../../common/datos.php");
include ("../../../common/listado.php");
?>
