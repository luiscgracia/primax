<?php
  include ("../normal/permisos.php");
?>
