<?php
  include ("../../conectar_db.php");
	include ("../../../../../normal/terminales/".$terminal."/formatos/01/formato_consultado.php");
?>
