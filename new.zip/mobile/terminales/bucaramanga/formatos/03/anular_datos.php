<?
$formato = basename(dirname(__FILE__));
include ("../../conectar_db.php");
include ("../../../../../normal/terminales/$terminal/formatos/$formato/anular_datos.php");
?>
