<script type="text/javascript">
/* esta parte es para el formato 01 */
function comprobarD1(obj)
{if (obj.checked) {document.getElementById('numeroD1').style.display=""; document.getElementById('numeroD1').required=true; document.getElementById('numeroD1').disabled=false}
	else {document.getElementById('numeroD1').disabled=true;	document.getElementById('numeroD1').style.display="none";}}
function comprobarD2(obj)
{if (obj.checked) {document.getElementById('numeroD2').style.display=""; document.getElementById('numeroD2').required=true; document.getElementById('numeroD2').disabled=false}
	else {document.getElementById('numeroD2').disabled=true;	document.getElementById('numeroD2').style.display="none";}}
function comprobarD3(obj)
{if (obj.checked) {document.getElementById('numeroD3').style.display=""; document.getElementById('numeroD3').required=true; document.getElementById('numeroD3').disabled=false}
	else {document.getElementById('numeroD3').disabled=true;	document.getElementById('numeroD3').style.display="none";}}
function comprobarD4(obj)
{if (obj.checked) {document.getElementById('numeroD4').style.display=""; document.getElementById('numeroD4').required=true; document.getElementById('numeroD4').disabled=false}
	else {document.getElementById('numeroD4').disabled=true;	document.getElementById('numeroD4').style.display="none";}}
function comprobarD5(obj)
{if (obj.checked) {document.getElementById('numeroD5').style.display=""; document.getElementById('numeroD5').required=true; document.getElementById('numeroD5').disabled=false}
	else {document.getElementById('numeroD5').disabled=true;	document.getElementById('numeroD5').style.display="none";}}
function comprobarD6(obj)
{if (obj.checked) {document.getElementById('numeroD6').style.display=""; document.getElementById('numeroD6').required=true; document.getElementById('numeroD6').disabled=false}
	else {document.getElementById('numeroD6').disabled=true;	document.getElementById('numeroD6').style.display="none";}}
function comprobarD7(obj)
{if (obj.checked) {document.getElementById('numeroD7').style.display=""; document.getElementById('numeroD7').required=true; document.getElementById('numeroD7').disabled=false}
	else {document.getElementById('numeroD7').disabled=true;	document.getElementById('numeroD7').style.display="none";}}
function comprobarD8(obj)
{if (obj.checked) {document.getElementById('numeroD8').style.display=""; document.getElementById('numeroD8').required=true; document.getElementById('numeroD8').disabled=false}
	else {document.getElementById('numeroD8').disabled=true;	document.getElementById('numeroD8').style.display="none";}}
function comprobarD9(obj)
{if (obj.checked) {document.getElementById('numeroD9').style.display=""; document.getElementById('numeroD9').required=true; document.getElementById('numeroD9').disabled=false}
	else {document.getElementById('numeroD9').disabled=true;	document.getElementById('numeroD9').style.display="none";}}
function comprobarD10(obj)
{if (obj.checked) {document.getElementById('numeroD10').style.display=""; document.getElementById('numeroD10').required=true; document.getElementById('numeroD10').disabled=false}
	else {document.getElementById('numeroD10').disabled=true; document.getElementById('numeroD10').style.display="none";}}
function comprobarD11(obj)
{if (obj.checked) {document.getElementById('numeroD11').style.display=""; document.getElementById('numeroD11').required=true; document.getElementById('numeroD11').disabled=false}
	else {document.getElementById('numeroD11').disabled=true; document.getElementById('numeroD11').style.display="none";}}
function comprobarD12(obj)
{if (obj.checked) {document.getElementById('numeroD12').style.display=""; document.getElementById('numeroD12').required=true; document.getElementById('numeroD12').disabled=false}
	else {document.getElementById('numeroD12').disabled=true; document.getElementById('numeroD12').style.display="none";}}
function comprobarD13(obj)
{if (obj.checked) {document.getElementById('numeroD13').style.display=""; document.getElementById('numeroD13').required=true; document.getElementById('numeroD13').disabled=false}
	else {document.getElementById('numeroD13').disabled=true; document.getElementById('numeroD13').style.display="none";}}
function comprobarD14(obj)
{if (obj.checked) {document.getElementById('numeroD14').style.display=""; document.getElementById('numeroD14').required=true; document.getElementById('numeroD14').disabled=false}
	else {document.getElementById('numeroD14').disabled=true; document.getElementById('numeroD14').style.display="none";}}
function comprobarD15(obj)
{if (obj.checked) {document.getElementById('numeroD15').style.display=""; document.getElementById('numeroD15').required=true; document.getElementById('numeroD15').disabled=false}
	else {document.getElementById('numeroD15').disabled=true; document.getElementById('numeroD15').style.display="none";}}
function comprobarD16(obj)
{if (obj.checked) {document.getElementById('numeroD16').style.display=""; document.getElementById('numeroD16').required=true; document.getElementById('numeroD16').disabled=false}
	else {document.getElementById('numeroD16').disabled=true; document.getElementById('numeroD16').style.display="none";}}
/* termina la parte del formato 01 */

/* esta parte es para el formato 03 */
function comprobarB12i(obj)
{if (obj.checked) {document.getElementById('guante').style.display=""; document.getElementById('guante').required=true; document.getElementById('guante').disabled=false}
	else {document.getElementById('guante').disabled=true;	document.getElementById('guante').style.display="none";}}
function comprobarB12m(obj)
{if (obj.checked) {document.getElementById('otro1').style.display=""; document.getElementById('otro1').required=true; document.getElementById('otro1').disabled=false}
	else {document.getElementById('otro1').disabled=true;	document.getElementById('otro1').style.display="none";}}
function comprobarB12j(obj)
{if (obj.checked) {document.getElementById('calzado').style.display=""; document.getElementById('calzado').required=true; document.getElementById('calzado').disabled=false}
	else {document.getElementById('calzado').disabled=true;	document.getElementById('calzado').style.display="none";}}
function comprobarB12n(obj)
{if (obj.checked) {document.getElementById('otro2').style.display=""; document.getElementById('otro2').required=true; document.getElementById('otro2').disabled=false}
	else {document.getElementById('otro2').disabled=true;	document.getElementById('otro2').style.display="none";}}
function comprobarB12k(obj)
{if (obj.checked) {document.getElementById('delantal').style.display=""; document.getElementById('delantal').required=true; document.getElementById('delantal').disabled=false}
	else {document.getElementById('delantal').disabled=true;	document.getElementById('delantal').style.display="none";}}
function comprobarB12o(obj)
{if (obj.checked) {document.getElementById('otro3').style.display=""; document.getElementById('otro3').required=true; document.getElementById('otro3').disabled=false}
	else {document.getElementById('otro3').disabled=true;	document.getElementById('otro3').style.display="none";}}
function comprobarB12l(obj)
{if (obj.checked) {document.getElementById('ropa').style.display=""; document.getElementById('ropa').required=true; document.getElementById('ropa').disabled=false}
	else {document.getElementById('ropa').disabled=true;	document.getElementById('ropa').style.display="none";}}
/* termina la parte del formato 03 */

/* esta parte es para el formato 05 */
function comprobarB11i(obj)
{if (obj.checked) {document.getElementById('guante').style.display=""; document.getElementById('guante').required=true; document.getElementById('guante').disabled=false}
	else {document.getElementById('guante').disabled=true;	document.getElementById('guante').style.display="none";}}
function comprobarB11m(obj)
{if (obj.checked) {document.getElementById('otro1').style.display=""; document.getElementById('otro1').required=true; document.getElementById('otro1').disabled=false}
	else {document.getElementById('otro1').disabled=true;	document.getElementById('otro1').style.display="none";}}
function comprobarB11j(obj)
{if (obj.checked) {document.getElementById('calzado').style.display=""; document.getElementById('calzado').required=true; document.getElementById('calzado').disabled=false}
	else {document.getElementById('calzado').disabled=true;	document.getElementById('calzado').style.display="none";}}
function comprobarB11n(obj)
{if (obj.checked) {document.getElementById('otro2').style.display=""; document.getElementById('otro2').required=true; document.getElementById('otro2').disabled=false}
	else {document.getElementById('otro2').disabled=true;	document.getElementById('otro2').style.display="none";}}
function comprobarB11k(obj)
{if (obj.checked) {document.getElementById('delantal').style.display=""; document.getElementById('delantal').required=true; document.getElementById('delantal').disabled=false}
	else {document.getElementById('delantal').disabled=true;	document.getElementById('delantal').style.display="none";}}
function comprobarB11o(obj)
{if (obj.checked) {document.getElementById('otro3').style.display=""; document.getElementById('otro3').required=true; document.getElementById('otro3').disabled=false}
	else {document.getElementById('otro3').disabled=true;	document.getElementById('otro3').style.display="none";}}
function comprobarB11l(obj)
{if (obj.checked) {document.getElementById('ropa').style.display=""; document.getElementById('ropa').required=true; document.getElementById('ropa').disabled=false}
	else {document.getElementById('ropa').disabled=true;	document.getElementById('ropa').style.display="none";}}
/* termina la parte del formato 05 */

/* esta parte es para el formato 08 */
function comprobarB10g(obj)
{if (obj.checked) {document.getElementById('B10g1').style.display=""; document.getElementById('B10g1').required=true; document.getElementById('B10g1').disabled=false}
	else {document.getElementById('B10g1').disabled=true;	document.getElementById('B10g1').style.display="none";}}
function comprobarB10h(obj)
{if (obj.checked) {document.getElementById('B10h1').style.display=""; document.getElementById('B10h1').required=true; document.getElementById('B10h1').disabled=false}
	else {document.getElementById('B10h1').disabled=true;	document.getElementById('B10h1').style.display="none";}}
function comprobarB10k(obj)
{if (obj.checked) {document.getElementById('B10k1').style.display=""; document.getElementById('B10k1').required=true; document.getElementById('B10k1').disabled=false}
	else {document.getElementById('B10k1').disabled=true;	document.getElementById('B10k1').style.display="none";}}
function comprobarB10l(obj)
{if (obj.checked) {document.getElementById('B10l1').style.display=""; document.getElementById('B10l1').required=true; document.getElementById('B10l1').disabled=false}
	else {document.getElementById('B10l1').disabled=true;	document.getElementById('B10l1').style.display="none";}}
/* termina la parte del formato 08 */
</script>
